const races = [
  ['14.03. - 16.03.','Australian Grand Prix'],
  ['21.03. - 23.03.','Chinese Grand Prix'],
  ['04.04. - 06.04.','Japanese Grand Prix'],
  ['11.04. - 13.04.','Bahrain Grand Prix'],
  ['18.04. - 20.04.','Saudi Arabian Grand Prix'],
  ['02.05. - 04.05.','U.S. Grand Prix - Miami'],
  ['16.05. - 18.05.','Italian Grand Prix (Emilia Romagna)'],
  ['23.05. - 26.05.','Monaco Grand Prix'],
  ['30.05. - 01.06.','Spanish Grand Prix'],
  ['13.06. - 16.06.','Canadian Grand Prix'],
  ['27.06. - 29.06.','Austrian Grand Prix'],
  ['04.07. - 06.07.','British Grand Prix'],
  ['25.07. - 27.07.','Belgian Grand Prix'],
  ['01.08. - 03.08.','Hungarian Grand Prix'],
  ['29.08. - 01.09.','Dutch Grand Prix'],
  ['05.09. - 07.09.','Italian Grand Prix'],
  ['19.09. - 21.09.','Azerbaijan Grand Prix'],
  ['03.10. - 05.10.','Singapore Grand Prix'],
  ['17.10. - 19.10.','US Grand Prix'],
  ['24.10. - 26.10.','Mexican Grand Prix'],
  ['07.11. - 09.11.','Brazilian Grand Prix'],
  ['20.11. - 22.11.','U.S. Grand Prix - Miami'],
  ['28.11. - 30.11.','Qatar Grand Prix'],
  ['05.12. - 07.12.','Abu Dhabi Grand Prix']
];

document.addEventListener('DOMContentLoaded', () => {
  const rows = document.getElementById('rows');
  if (rows) {
    rows.innerHTML = races.map(([date, race]) =>
      `<div class="date">${date}</div><div class="race">${race}</div>`
    ).join('');
  }

  
  const menuBtn = document.getElementById('menuBtn');
  const menu = document.getElementById('menu');
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', e => {
      const open = menuBtn.getAttribute('aria-expanded') === 'true';
      menuBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
      menu.toggleAttribute('hidden', open);
      e.stopPropagation();
    });
    document.addEventListener('click', e => {
      if (!menu.contains(e.target) && !menuBtn.contains(e.target)) {
        menuBtn.setAttribute('aria-expanded', 'false');
        menu.setAttribute('hidden', '');
      }
    });
  }
});